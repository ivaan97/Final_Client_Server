import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JOptionPane;


public class Client {
	public static void main(String[] args) {
		
		calcMsg msg = new calcMsg();
		AuthentificationMsg profil1 = new AuthentificationMsg("user", "1234");
		
		String serverAddress = JOptionPane.showInputDialog(
	            "Enter IP Address of a machine that is\n" +
	            "running the date service on port 9190:");
		
//		String username = JOptionPane.showInputDialog("Enter username:");
//		
//		if(username.equals(profil1.getUser())){
//			
//			String password = JOptionPane.showInputDialog("Enter password:");
//			
//				if(password.equals(profil1.getPassw())){
//					
					
					
					///////////////////////////////////////
					
					
					

					
					
					
					String calc = JOptionPane.showInputDialog(
				            "Enter calculation \n");
					
					msg.setMessage(calc);
					
					
				        Socket s = null;
						try {
							s = new Socket(serverAddress, 9190);
						} catch (IOException e) {
							e.printStackTrace();
						}
				   
				        ObjectInputStream input = null;
						try {
							input = new ObjectInputStream(s.getInputStream());
						} catch (IOException e) {
							e.printStackTrace();
						}
				        
				        ObjectOutputStream sendCalc = null;
						try {
							sendCalc = new ObjectOutputStream(s.getOutputStream());
						} catch (IOException e) {
							e.printStackTrace();
						}
			           
							try {
								sendCalc.writeObject(calc);
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
				        
			                try {
								sendCalc.flush();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
			                System.out.println(calc);
				       
			                String erg = null;
							try {
								erg = input.readLine();
							} catch (IOException e) {
								e.printStackTrace();
							}
			                System.out.println(erg);
			                JOptionPane.showMessageDialog(null, "The solution is: " + erg);

			                
			                
				        try {
							s.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
				        
					
					
					
					
					
					//////////////////////////////////////////
					
					
					
					
//					
//				}else{
//					JOptionPane.showMessageDialog(null, "Permission denied! Wrong password!");
//				}
//		}else{
//			 JOptionPane.showMessageDialog(null, "Permission denied! Unknown user!");
//		}
		
		
	}
}
