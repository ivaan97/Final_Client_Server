
public class AuthentificationMsg extends Message{

	private String user = null;
	private String passw = null;
	
	
	
	public AuthentificationMsg(String user, String passw) {
		super();
		this.user = user;
		this.passw = passw;
	}


	public void setAuthentification(String user, String passw) {
		this.user = user;
		this.passw = passw;
	}

	
	public String getUser() {
		return user;
	}
	
	public String getPassw(){
		return passw;
	}

	public void setMessage(String message) {
		
	}


	@Override
	public String getMessage() {
		return null;
	}

	
}
