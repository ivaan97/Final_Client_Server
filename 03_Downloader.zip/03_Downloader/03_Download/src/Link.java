
public class Link extends Message  {





}